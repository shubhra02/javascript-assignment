window.onload = function() {
var subBtn = document.getElementById('submit-btn');

subBtn.addEventListener('click', function(event){
  event.preventDefault();
  event.stopPropagation();

  var user={
    userName : "",
    password : ""
  };

  user.userName = document.getElementById('t1').value;
  user.password = document.getElementById('t2').value;

  var userNameError = false;
  var passwordError = false;

  if(user.userName != "shubhra") {
    userNameError = true;
  }
  if(user.password != "sharma") {
    passwordError = true;
  }

  alert('userName ' + user.userName);
  if(userNameError) {
    var userPara = document.getElementById('para-user-name');
    userPara.textContent = 'Incorrect user name';
    return;
  }

  if(passwordError) {
    var passPara = document.getElementById('para-password');
    passPara.textContent = "Incorrect password";
    return;
  }

}, false);
}
