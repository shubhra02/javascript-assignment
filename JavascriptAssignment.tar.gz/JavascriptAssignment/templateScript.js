function updateTime(){
        var date=new Date();
        var time = date.toLocaleTimeString();
        document.getElementById("timer").innerHTML= "<b>Local Time: "+time+"</b>";
        }

        window.onload=function(){
        updateTime();

        }
        //update local time every second
        setInterval(function(){
        updateTime();
      },1000);
